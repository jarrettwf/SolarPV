from django.apps import AppConfig


class BackendConfig(AppConfig):
    name = 'backend'
